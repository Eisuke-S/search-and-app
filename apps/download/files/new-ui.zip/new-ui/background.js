// background.js

// 拡張機能のインストール時やアップデート時に実行される処理
chrome.runtime.onInstalled.addListener(() => {
  console.log("Sidebar Toggle Extension installed or updated.");
});

// タブの変更を監視（オプション）
chrome.tabs.onActivated.addListener((activeInfo) => {
  console.log("Tab switched: ", activeInfo.tabId);
});
