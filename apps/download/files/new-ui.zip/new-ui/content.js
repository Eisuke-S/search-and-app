// サイドバーを作成する関数
const createSidebar = () => {
  const sidebar = document.createElement('div');
  sidebar.classList.add('custom-sidebar');
  sidebar.id = 'custom-sidebar';  // クラスと同じIDを追加
  sidebar.style.transform = 'translateX(-100%)';  // 初期状態で画面外に配置
  document.body.appendChild(sidebar);
  return sidebar;
};

// ボタンを作成する関数
const createButton = () => {
  const button = document.createElement('button');
  button.classList.add('toggle-button');
  document.body.appendChild(button);
  return button;
};

// サイドバーの表示/非表示を切り替える関数
const toggleSidebarVisibility = (sidebar, button) => {
  if (sidebar.style.transform === 'translateX(-100%)') {
    sidebar.style.transform = 'translateX(0)';  // サイドバーをスライドイン
    button.style.opacity = 0;  // サイドバーが表示されているときはボタンを非表示
    button.style.pointerEvents = 'none';  // ボタンがクリックされないようにする
  } else {
    sidebar.style.transform = 'translateX(-100%)';  // サイドバーをスライドアウト
    button.style.opacity = 1;  // サイドバーが非表示のときはボタンを再表示
    button.style.pointerEvents = 'auto';  // ボタンを再びクリックできるようにする
  }
};

// サイドバーとボタンを作成し、イベントリスナーを設定する関数
const setupSidebarAndButton = () => {
  const sidebar = createSidebar();
  const button = createButton();

  // ボタンのクリックとホバーでサイドバーの表示/非表示を切り替え
  const toggleSidebar = () => toggleSidebarVisibility(sidebar, button);
  button.addEventListener('click', toggleSidebar);
  button.addEventListener('mouseenter', toggleSidebar);

  // サイドバーが閉じられたときにボタンを再表示
  sidebar.addEventListener('mouseleave', () => {
    sidebar.style.transform = 'translateX(-100%)';  // サイドバーをスライドアウト
    button.style.opacity = 1;  // サイドバーが非表示のときはボタンを表示
    button.style.pointerEvents = 'auto';  // ボタンをクリックできるようにする
  });
};

// サイドバーとボタンのセットアップを実行
setupSidebarAndButton();
