// class="gb_Re" の要素を取得
const gbReElement = document.querySelector('.gb_Re');


// custom-sidebarの要素を取得
const sidebar = document.getElementById('custom-sidebar');

// 要素が存在する場合に処理
if (gbReElement && sidebar) {
  // 親要素から分離（必要な場合）
  gbReElement.remove();

  // サイドバーの一番下に追加
  sidebar.appendChild(gbReElement);
  
  // 必要に応じて強制的に動かす
  gbReElement.style.position = 'absolute'; // サイドバー内で絶対的に配置
  gbReElement.style.bottom = '0px';         // 下端に配置
  gbReElement.style.left = '0px';           // 左端に配置
  gbReElement.style.width = '100%';         // 横幅をサイドバーに合わせる
  gbReElement.style.zIndex = '9999';        // 他の要素より上に表示
  // マージンを追加してスペースを調整
  gbReElement.style.marginBottom = '20px';  // 下部に20pxの余白を追加
  gbReElement.style.marginLeft = '10px';    // 左に10pxの余白を追加（必要に応じて調整）
  gbReElement.style.marginRight = '10px';   // 右に10pxの余白を追加（必要に応じて調整）
}

