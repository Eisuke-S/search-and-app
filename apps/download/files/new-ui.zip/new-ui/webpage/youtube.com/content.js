// id="guide-wrapper" の要素を取得
const guideWrapperElement = document.getElementById('guide-wrapper');

// custom-sidebar の要素を取得
const sidebar = document.getElementById('custom-sidebar');

// guide-wrapper を移動
if (guideWrapperElement && sidebar) {
  // 親要素から分離
  guideWrapperElement.remove();

  // サイドバーの中に追加
  sidebar.appendChild(guideWrapperElement);

  // guide-wrapper のスタイルを調整
  guideWrapperElement.style.position = 'absolute'; // サイドバー内で絶対的に配置
  guideWrapperElement.style.top = '0px';           // 上端に配置
  guideWrapperElement.style.left = '0px';          // 左端に配置
  guideWrapperElement.style.width = '95%';        // 横幅をサイドバーに合わせる
  guideWrapperElement.style.overflow = 'auto';    
  guideWrapperElement.style.marginTop = '0';
}

// id="start"を持つ要素を削除
const logo = document.getElementById('start');
if (logo) {
  logo.remove();
}
const logo2 = document.getElementById('header');
if (logo2) {
  logo2.remove();
}


