// ページの読み込み完了時に処理を実行
window.addEventListener('load', () => {
  // 対象のロゴや削除対象のクラスを指定するセレクタ
  const logoSelectors = [
    'img[alt="Google"]',      // メインロゴ画像
    '#logo img',              // 左上の画像ロゴ
    '#logo svg',              // 左上のSVGロゴ
    'img.lnXdpd[alt="Google"]' // ニュースページのロゴ
  ];

  const deleteSelectors = [
    '.DD4Hed',                // 削除対象: DD4Hed クラス
    'svg.lJpQBb',             // 削除対象: SVG要素 (lJpQBb クラス)
    '.uU7dJb',                // 削除対象: uU7dJb クラス
    'div[jscontroller="NzU6V"].KxwPGc.SSwjIe', // 削除対象: 特定の div
    '.eboQFe'                 // 削除対象: eboQFe クラス
  ];

  // ウィンドウ幅の変化を追跡
  let previousWidth = window.innerWidth;

  // ロゴのサイズや削除処理を更新する関数
  const updatePageElements = () => {
    const currentWidth = window.innerWidth;

    // === 削除処理 ===
    deleteSelectors.forEach(selector => {
      document.querySelectorAll(selector).forEach(element => {
        element.remove(); // 対象の要素を削除
      });
    });

    // === ロゴサイズの調整 ===
    logoSelectors.forEach(selector => {
      const logoElement = document.querySelector(selector);

      if (logoElement) {
        const parent = logoElement.parentElement; // ロゴの親要素を取得

        // 元のロゴを削除
        logoElement.remove();

        // 代わりに「Origo Search」というテキストを挿入
        const textElement = document.createElement('div');
        textElement.textContent = 'Origo Search';
        textElement.style.fontFamily = 'Source Code Pro, monospace';

        // ロゴの高さや幅を取得し、デフォルト値を設定
        const logoHeight = logoElement.height || logoElement.clientHeight || 20;
        const logoWidth = logoElement.width || logoElement.clientWidth || 100;

        // フォントサイズを計算 (高さと幅の両方を考慮)
        const fontSizeHeight = Math.max(logoHeight * 0.8, 16); // 高さの80%を適用、最小16px
        const fontSizeWidth = Math.max(logoWidth * 0.2, 16);   // 幅の20%を適用、最小16px
        const adjustmentFactor = currentWidth > previousWidth ? 0.9 : 1.1; // 幅の増減による調整
        const fontSize = Math.min(fontSizeHeight, fontSizeWidth) * adjustmentFactor;

        // スタイルを設定
        textElement.style.fontSize = `${fontSize}px`;
        textElement.style.fontWeight = 'bold';
        textElement.style.color = '#4CAF50'; // 色: 緑
        textElement.style.display = 'inline-block';
        textElement.style.verticalAlign = 'middle'; // 縦位置調整
        textElement.style.whiteSpace = 'nowrap'; // テキストの改行を防ぐ

        // 親要素に挿入
        if (parent) {
          parent.appendChild(textElement);
        }
      }
    });

    // ウィンドウ幅を更新
    previousWidth = currentWidth;
  };

  // 初回実行
  updatePageElements();

  // ウィンドウサイズ変更時に実行
  window.addEventListener('resize', updatePageElements);

  // DOMの変更を監視 (MutationObserver)
  const observer = new MutationObserver(() => {
    updatePageElements(); // DOMに変化があれば更新
  });

  // 監視対象を設定
  observer.observe(document.body, {
    childList: true,     // 子要素の追加・削除を監視
    subtree: true,       // DOMツリー全体を監視
    attributes: true     // 属性の変更も監視
  });
});
