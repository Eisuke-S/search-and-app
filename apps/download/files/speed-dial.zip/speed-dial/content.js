// 現在のURLがGoogle検索ページの場合のみダイヤルを表示
const shouldDisplayDial = () => {
    const currentURL = window.location.href;
    return !currentURL.startsWith("https://www.google.com/search?q=");
};

// スピードダイヤルの作成
const createSpeedDial = () => {
    if (!shouldDisplayDial()) return; // Googleの検索結果ページでは表示しない

    const container = document.createElement('div');
    container.id = 'speed-dial';
    container.style = `
        position: fixed;
        bottom: 20px; /* 下部に配置 */
        left: 50%;
        transform: translateX(-50%);
        display: none; /* 初期状態は非表示 */
        justify-content: center;
        align-items: center;
        gap: 15px;
        background: rgba(255, 255, 255, 0.7); /* 半透明の白背景 */
        border-radius: 50px;
        box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.3);
        z-index: 10000; /* 他の要素より前面に表示 */
        padding: 10px 20px; /* ダイヤルと周囲の余白を作成 */
        max-width: 90%;
        overflow: hidden;
        height: 70px; /* 高さ */
        transition: transform 0.3s ease;
    `;
    document.body.appendChild(container);

    renderDial(); // ダイヤルアイテムの描画
};

// サイト情報を保存
const saveSite = (site) => {
    chrome.storage.local.get({ sites: [] }, (data) => {
        const updatedSites = [...data.sites, site];
        chrome.storage.local.set({ sites: updatedSites }, renderDial); // 再描画
    });
};

// サイト情報を削除
const deleteSite = (index) => {
    chrome.storage.local.get({ sites: [] }, (data) => {
        const updatedSites = data.sites.filter((_, i) => i !== index);
        chrome.storage.local.set({ sites: updatedSites }, renderDial); // 再描画
    });
};

// スピードダイヤルの描画
const renderDial = () => {
    const container = document.getElementById('speed-dial');

    chrome.storage.local.get({ sites: [] }, (data) => {
        const sites = data.sites;

        // サイトが空の場合、Dockを非表示
        if (sites.length === 0) {
            container.style.display = 'none';
            return;
        }

        // サイトが存在する場合、Dockを表示
        container.style.display = 'flex';

        // 既存のアイテムを削除
        const existingItems = container.querySelectorAll('.dial-item');
        existingItems.forEach(item => item.remove());

        // 各サイトを描画
        sites.forEach((site, index) => {
            const item = document.createElement('a');
            item.href = site.url;
            item.className = 'dial-item';
            item.style = `
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 6px;
                background: rgba(255, 255, 255, 0.8);
                border-radius: 50%;
                text-decoration: none;
                color: black;
                cursor: pointer;
                width: 50px;
                height: 50px;
                position: relative;
                border: 2px solid #fff;
                transition: transform 0.3s ease;
            `;

            const favicon = document.createElement('img');
            favicon.src = `https://www.google.com/s2/favicons?domain=${site.url}&sz=256`; // 高解像度ファビコン
            favicon.alt = 'favicon';
            favicon.style = `
                width: 30px;
                height: 30px;
                margin-bottom: 6px;
                transition: transform 0.3s ease;
            `;
            item.appendChild(favicon);

            const title = document.createElement('span');
            title.textContent = site.title;
            title.style = `
                text-align: center; /* 中央揃え */
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 50px; /* アイコンの幅に合わせて最大幅を設定 */
                font-size: 10px;
            `;
            item.appendChild(title);

            // 削除ボタン
            const deleteButton = document.createElement('div');
            deleteButton.textContent = '×';
            deleteButton.style = `
                position: absolute;
                top: 4px;
                right: 4px;
                background: rgba(255, 255, 255, 0.7);
                border-radius: 50%;
                padding: 4px;
                font-size: 16px;
                color: red;
                cursor: pointer;
                display: none;
            `;
            deleteButton.onclick = (e) => {
                e.stopPropagation(); // クリックイベントの伝播を止める
                deleteSite(index); // サイト削除
            };
            item.appendChild(deleteButton);

            // ホバー時の動作
            item.onmouseenter = () => {
                deleteButton.style.display = 'block';
                item.style.transform = 'scale(1.1)';
                favicon.style.transform = 'scale(1.2)';
            };
            item.onmouseleave = () => {
                deleteButton.style.display = 'none';
                item.style.transform = 'scale(1)';
                favicon.style.transform = 'scale(1)';
            };

            container.appendChild(item);
        });
    });
};

// 初期化
createSpeedDial();
