chrome.runtime.onInstalled.addListener(() => {
    // 右クリックメニュー設定
    chrome.contextMenus.create({
        id: "addToDial",
        title: "Add to Speed Dial",
        contexts: ["link", "page"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "addToDial") {
        let site = null;
        if (info.linkUrl) {
            site = { url: info.linkUrl, title: info.linkText || "No title" };
        } else {
            site = { url: tab.url, title: tab.title || "No title" };
        }
        if (site) {
            chrome.storage.local.get({ sites: [] }, (data) => {
                const updatedSites = [...data.sites, site];
                chrome.storage.local.set({ sites: updatedSites });
            });
        }
    }
});
